function bintangg1(rentang) {
    let hasil = '';
    for (let i = 0; i < rentang; i++) {
        for (let j = 0; j <= i; j++) {
            hasil += '* ';
        }
        hasil += '\n';
    }
    return hasil;
}
console.log(bintangg1(4));

function bintangg2(rentang) {
    let hasil = '';
    for (let i = 0; i < rentang; i++) {
        for (let j = rentang; j > i; j--) {
            hasil += '* ';
        }
        hasil += '\n';
    }
    return hasil;
}
console.log(bintangg2(4));

function bintangg3(rentang) {
    let hasil = '';
    for (let i = 0; i < rentang-1; i++) {
        for (let j = rentang; j > i; j--) {
           
          hasil += '* ';
        }
        hasil += '\n';
    }
     for (let i = 0; i < rentang  ; i++) {
        for (let j = 0; j <= i; j++) {
            hasil += '* ';
        }
        hasil += '\n';
    }
    return hasil;
}
console.log(bintangg3(4));

function bintangg4(rentang) {
    let hasil = '';
    for (let i = 0; i < rentang; i++) {
        for (let j = 0; j <= i-1; j++) {
            hasil += '* ';
        }
        hasil += '\n';
    }
    for (let i = 0; i < rentang; i++) {
        for (let j = rentang; j > i; j--) {
           
          hasil += '* ';
        }
        hasil += '\n';
    }
   
    return hasil;
}
console.log(bintangg4(4));